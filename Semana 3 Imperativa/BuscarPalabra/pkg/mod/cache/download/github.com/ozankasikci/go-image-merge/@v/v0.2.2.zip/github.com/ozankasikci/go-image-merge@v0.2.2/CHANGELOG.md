## v0.2.2 - 2019-12-01
### Bug Fixes
- Check images before trying to merge 

## v0.2.1 - 2019-11-29
### Features
- Export readImageFile method

## v0.2.0 - 2019-09-29

### Breaking Changes
- gim.New won't accept a []string argument anymore, instead it now expects a []*Grid slice as first argument.

### Features
- Add Background color support
- Add Grid Layered drawing support

## v0.1.0 - 2019-09-28

### Features
- Initial version
- Vertical & Horizontal grid unit count option
- Functional option BaseDir
- Functional option GridSize
- Functional option GridSizeFromNthImage

